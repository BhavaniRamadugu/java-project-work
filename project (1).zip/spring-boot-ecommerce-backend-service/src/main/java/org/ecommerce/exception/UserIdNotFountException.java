package org.ecommerce.exception;

public class UserIdNotFountException extends Exception {
	
	public UserIdNotFountException(String message)
	{
		super(message);
		
	}

}
