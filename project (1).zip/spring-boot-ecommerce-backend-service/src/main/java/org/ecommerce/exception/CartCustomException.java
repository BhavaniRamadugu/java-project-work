package org.ecommerce.exception;

public class CartCustomException extends Exception {

	

	public CartCustomException(String message)
	{
		super(message);
		
	}
}
